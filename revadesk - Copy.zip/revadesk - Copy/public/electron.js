// Modules to control application life and create native browser window
const { app: electronApp, ipcMain, BrowserWindow } = require("electron");
const totp = require("totp-generator");
const { v4: uuidv4 } = require("uuid");
const fs = require("fs");
const path = require("path");
var child = require('child_process').execFile

//const Driver = require('./class/Driver.js');

function createWindow() {
  const mainWindow = new BrowserWindow({
    autoHideMenuBar: true,
    simpleFullscreen:true,

    // maxWidth:true,
    // maxHeight:true,
    icon: path.join(__dirname, "build/logo192.png"),
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  });

  mainWindow.loadFile("build/index.html");
  
}

electronApp.whenReady().then(() => {
  createWindow();
  

  electronApp.on("activate", function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });

  child("webapi\\publish\\webapi.exe",function(err,data){
      
      // if(err){
      //   alert('i got failed')
      // }
      // else{
      //   alert('i am sucessful')
      // }
  
    })
});

electronApp.on("window-all-closed", function () {
  if (process.platform !== "darwin") electronApp.quit();
});

