import logo from './logo.svg';
import './App.css';
//import '../preload.js';
const ipcRenderer = window.require('electron').ipcRenderer;

function App() {

  return (
    <div className="App">
      <h1>WElcome to React</h1>
      <button id="RunWebApi" onclick="RunWebApi();">
                Load Web Api
      </button>
    </div>
  );
}

export default App;
