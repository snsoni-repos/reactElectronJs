import logo from './logo.svg';
import './App.css';
import { useState } from 'react';
//import '../preload.js';
const ipcRenderer = window.require('electron').ipcRenderer;

function App() {
  const [data,setData] = useState([]);
  const RunWebApi = async () => {
    await fetch("http://127.0.0.1:5000/weatherforecast").then(async (resp)=>{
      let data = await resp.json();
      setData(data);
        console.log(resp,data)
      })
  }
  return (
    <div className="App">
      <h1>WElcome to React</h1>
      <button id="RunWebApi" onClick={RunWebApi}>
                Load Web Api
      </button>
      {data.length > 0 && data.map((item)=>(
        <>
        <p>
          {JSON.stringify(item)}
        </p>
        </>
        ))}
    </div>
  );
}

export default App;
