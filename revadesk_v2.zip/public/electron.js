// Modules to control application life and create native browser window
const { app: electronApp, ipcMain, BrowserWindow } = require("electron");
const totp = require("totp-generator");
const { v4: uuidv4 } = require("uuid");
const fs = require("fs");
const path = require("path");
var {spawn} = require('child_process')
var child = require('child_process').execFile
require("dotenv").config();

//const Driver = require('./class/Driver.js');
let webApiProcess;
function createWindow() {
  const mainWindow = new BrowserWindow({
    autoHideMenuBar: true,
    simpleFullscreen:true,

    // maxWidth:true,
    // maxHeight:true,
    icon: path.join(__dirname, "build/logo192.png"),
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  });

  mainWindow.loadFile("build/index.html");
  
}

electronApp.whenReady().then(() => {
  let webApiPath;
  console.log(process.env.NODE_ENV)
  if(process.env.NODE_ENV === "development"){
    webApiPath = path.join(__dirname,"../webapi/publish")
  }else{
    webApiPath = path.join(process.resourcesPath,"\\webapi\\publish")
  }
  console.log({webApiPath})
  webApiProcess = spawn("webapi.exe", ['run'], {
    cwd:webApiPath,
    shell: false,
  });
  createWindow();
  electronApp.on("activate", function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

electronApp.on("window-all-closed", function () {
  webApiProcess.kill();
  if (process.platform !== "darwin") electronApp.quit();
});

